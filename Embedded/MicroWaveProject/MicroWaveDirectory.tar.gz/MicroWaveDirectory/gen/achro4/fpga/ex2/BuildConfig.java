/** Automatically generated file. DO NOT MODIFY */
package achro4.fpga.ex2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}