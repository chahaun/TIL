package achro4.fpga.ex2;

import android.os.*;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.*;

public class FpgaFndActivity extends Activity {

	EditText time;
	Button plusTenSec, minusTenSec;
	Button exitButton, startButton, pauseButton, finishButton;
	Button button1, button2, button3, button4, thaw, smoke;
	String settingTime;
	int mode = 0;
	boolean task;
	
	int timeSec = 0;
	int fnd_result;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		time = (EditText) findViewById(R.id.editText1);
		plusTenSec = (Button) findViewById(R.id.button9);
		minusTenSec = (Button) findViewById(R.id.button8);
		exitButton = (Button) findViewById(R.id.button1);
		startButton = (Button) findViewById(R.id.button10);
		pauseButton = (Button) findViewById(R.id.button11);
		finishButton = (Button) findViewById(R.id.button12);
		button1 = (Button) findViewById(R.id.button2);
		button2 = (Button) findViewById(R.id.button3);
		button3 = (Button) findViewById(R.id.button4);
		button4 = (Button) findViewById(R.id.button5);
		thaw = (Button) findViewById(R.id.button6);
		smoke = (Button) findViewById(R.id.button7);
		
		ReceiveTextLcdValue("Hello!", "It's KPU_MICRO!");
		
		//아래에 써있는 setOnClickListener들은 각 버튼을 누를때의 메소드가 들어가있다.
        plusTenSec.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                if(timeSec >= 0)
                    timeSec += 10;
                setTextView();
                settingTime = String.valueOf(timeSec);
                ReceiveTextLcdValue("10Sec Plus", "Total : " + settingTime);
            }
        });

        minusTenSec.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                if(timeSec > 0)
                    timeSec -= 10;
                setTextView();
                settingTime = String.valueOf(timeSec);
                ReceiveTextLcdValue("10Sec Minus", "Total : " + settingTime);
            }
        });

        //30 Sec
        button1.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                if(timeSec >= 0)
                    timeSec += 30;
                setTextView();
                settingTime = String.valueOf(timeSec);
                ReceiveTextLcdValue("30Sec Plus", "Total : " + settingTime);
            }
        });

        //45 Sec
        button2.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                if(timeSec >= 0)
                    timeSec += 45;
                setTextView();
                settingTime = String.valueOf(timeSec);
                ReceiveTextLcdValue("45Sec Plus", "Total : " + settingTime);
            }
        });

        //1 min
        button3.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                if(timeSec >= 0)
                    timeSec += 60;
                setTextView();
                settingTime = String.valueOf(timeSec);
                ReceiveTextLcdValue("1Min Plus", "Total : " + settingTime);
            }
        });

        //2m 30sec
        button4.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                if(timeSec >= 0)
                    timeSec += 150;
                setTextView();
                settingTime = String.valueOf(timeSec);
                ReceiveTextLcdValue("2Min 30Sec Plus", "Total : " + settingTime);
            }
        });
        
        thaw.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				mode = 1;
				settingTime = String.valueOf(timeSec);
                ReceiveTextLcdValue("Mode : Thaw", "Total : " + settingTime);
			}
		});
        
        smoke.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				mode = 2;
				settingTime = String.valueOf(timeSec);
                ReceiveTextLcdValue("Mode : Smoke", "Total : " + settingTime);
			}
		});

        exitButton.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                finish();
                ReceiveTextLcdValue("Bye!", "See ya!");
            }
        });

        startButton.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
            	if(task != true) {
            		task = true;
                    new CounterTask().execute();
                    if(mode == 0)
                    	SetMotorState(1, 1, 10);
                    else if(mode == 1)
                    	SetMotorState(1, 1, 5);
                    else
                    	SetMotorState(1, 1, 15);
                    ReceiveTextLcdValue("Start!!", "Set : " + settingTime);
            	}
            }
        });

        pauseButton.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                task = false;
                SetMotorState(0, 0, 0);
                ReceiveTextLcdValue("Pause", "Set : " + settingTime);
            }


        });
        finishButton.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                timeSec = 0;
                setTextView();
                SetMotorState(0, 0, 0);
                ReceiveFndValue("0");
                ReceiveTextLcdValue("Finish!", "It's Over! >3<");
                task = false;
            }
        });
    }

    //EditText로 표현해줄 때, 쓰는 메소드. 돌아갈 때도 사용은 하지만, start와 pause버튼때는 쓰지 않는다.
    //이유는 AsyncTask는 비동기기 때문에 이것을 쓰다간 UI쓰레드에서 쓰지 않았다고 뻑난다.
    public void setTextView() {
        int share = 0;          //'분'에 해당하는 값을 담는 정수
        int rest = 0;           //'초'에 해당하는 값을 담는 정수
        String share_str = null;    //EditText에 값을 넣으려면, String으로 있어야한다.
        String rest_str = null;     //share_str과 마찬가지

        share = timeSec / 60;       //분 값 계산
        rest = timeSec % 60;        //초 값 계산

        share_str = Integer.toString(share);    //String으로 형변환

        if(rest < 10)
            rest_str = "0" + Integer.toString(rest);        //10초 미만이면, 앞에 0 붙이고 String 형변환
        else
            rest_str = Integer.toString(rest);              //10초 이상이면, 그냥 형변환

        time.setText(share_str + " : " + rest_str);         //EditText에 값 집어넣기.
    }

    //start버튼을 눌렀을 때, 이행되는 비동기 클래스. 서브쓰레드에서 사용할 수 없으니 AsyncTask로 비동기화했다.
    class CounterTask extends AsyncTask<Void, Integer, Integer> {

        @Override
        protected Integer doInBackground(Void... voids) {

            while(timeSec > 0) {
            	if(task == false)
            		return 0;
            	try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                timeSec -= 1;
                publishProgress(timeSec);
            }

            timeSec = 0;
            return timeSec;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
        	if(task != false) {
        		String str_time = String.valueOf(timeSec);
    	    	ReceiveFndValue(str_time);

                int share = 0;
                int rest = 0;
                String share_str = null;
                String rest_str = null;

                share = timeSec / 60;
                rest = timeSec % 60;

                share_str = Integer.toString(share);

                if(rest < 10)
                    rest_str = "0" + Integer.toString(rest);
                else
                    rest_str = Integer.toString(rest);

                time.setText(share_str + " : " + rest_str);
        	}
        }

        @Override
        protected void onPostExecute(Integer integer) {
            ReceiveBuzzerValue(1);
            SetMotorState(0, 0, 0);
            ReceiveTextLcdValue("Finish!", "It's Over! >3<");
            try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            ReceiveBuzzerValue(0);
            
            if(timeSec < 0)
            	time.setText("0 : 00");
        }
    }

    public native int ReceiveFndValue(String ptr);
    public native int ReceiveTextLcdValue(String str1, String str2);
    public native int ReceiveBuzzerValue(int bval);
    public native String SetMotorState(int mval1, int mval2, int mval3);

    static {
        System.loadLibrary("fpga-microwave-jni");
    }
}
